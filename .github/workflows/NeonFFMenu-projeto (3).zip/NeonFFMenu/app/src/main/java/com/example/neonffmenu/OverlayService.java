package com.example.neonffmenu;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.Handler;
import android.app.ActivityManager;
import android.content.Context;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private Handler handler = new Handler();
    private final Runnable updater = new Runnable() {
        @Override public void run() {
            if (panel instanceof LinearLayout) {
                LinearLayout box = (LinearLayout) panel;
                if (box.getChildCount() > 1) {
                    TextView metrics = (TextView) box.getChildAt(1);
                    ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                    ((ActivityManager)getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
                    long freeMb = mi.availMem / (1024 * 1024);
                    metrics.setText("RAM livre: " + freeMb + " MB\nStatus: painel ativo");
                }
            }
            handler.postDelayed(this, 2000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 12, 18, 12);
        box.setBackgroundColor(Color.rgb(20, 10, 14));

        TextView header = new TextView(this);
        header.setText("NEON MENU   [×]");
        header.setTextColor(Color.rgb(255, 35, 65));
        header.setTextSize(16);
        header.setOnClickListener(v -> stopSelf());
        box.addView(header);

        TextView metrics = new TextView(this);
        metrics.setTextColor(Color.WHITE);
        metrics.setTextSize(12);
        metrics.setPadding(0, 10, 0, 0);
        box.addView(metrics);
        panel = box;

        int type = Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 20; p.y = 140;
        wm.addView(panel, p);
        handler.post(updater);
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(updater);
        if (wm != null && panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
