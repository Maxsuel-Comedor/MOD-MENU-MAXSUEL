package com.example.neonffmenu;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int red = Color.rgb(255, 35, 65);
    private LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(Color.rgb(12, 12, 16));

        TextView title = new TextView(this);
        title.setText("NEON  /  FF MENU");
        title.setTextColor(red);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, match(-2));

        TextView sub = new TextView(this);
        sub.setText("PAINEL VISUAL • SEM KEY • SEM CHEATS");
        sub.setTextColor(Color.LTGRAY);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 10, 0, 24);
        root.addView(sub, match(-2));

        Button overlay = button("ATIVAR PAINEL FLUTUANTE");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, OverlayService.class));
            }
        });
        root.addView(overlay, match(-2));

        Button color = button("ALTERNAR TEMA: VERMELHO / ROXO");
        color.setOnClickListener(v -> {
            red = red == Color.rgb(255,35,65) ? Color.rgb(190,70,255) : Color.rgb(255,35,65);
            title.setTextColor(red);
            overlay.setTextColor(red);
            color.setTextColor(red);
        });
        root.addView(color, match(-2));

        TextView note = new TextView(this);
        note.setText("\nO painel mostra informações básicas do próprio app/dispositivo.\nNão lê nem altera a memória do Free Fire e não oferece mira automática.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        root.addView(note, match(-2));
        setContentView(root);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(red);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(34, 15, 20)));
        b.setAllCaps(false);
        b.setPadding(10, 14, 10, 14);
        return b;
    }
    private LinearLayout.LayoutParams match(int h) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h);
    }
}
