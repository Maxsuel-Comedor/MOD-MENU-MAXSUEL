# Neon FF Menu (projeto Android)

Projeto-base de um painel visual próprio, sem licença/key, com tema preto/vermelho neon.

## Inclui
- Tela inicial com tema gamer e alternância vermelho/roxo.
- Painel flutuante opcional (o Android solicita permissão de sobreposição).
- Indicador simples de RAM livre do dispositivo.

## Limitações
- Não é um APK compilado: este arquivo contém o projeto-fonte.
- Não lê FPS real do Free Fire; Android não expõe esse dado a um app comum.
- Não altera o jogo, memória, mira, recoil, hitbox ou arquivos do Free Fire.

## Gerar APK
Abra a pasta no Android Studio com Android SDK instalado, aguarde a sincronização do Gradle e selecione:
Build > Build APK(s).
O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

Requer Android Studio/SDK e conexão para baixar dependências na primeira compilação.

## Gerar APK sem computador (GitHub Actions)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta para ele.
2. Abra a aba **Actions** do repositório e permita Actions, se solicitado.
3. Execute **Build Android APK** em **Run workflow** (ou envie um commit para `main`/`master`).
4. Quando terminar, abra a execução concluída e baixe o artefato **NeonFFMenu-debug-apk**.
5. Extraia o ZIP do artefato; o arquivo `app-debug.apk` é o instalador de teste.
6. No Android, abra o APK e permita instalar apps dessa origem quando o sistema solicitar.

O APK de depuração não é assinado para distribuição pela Play Store. Revise e teste o projeto antes de instalar.
